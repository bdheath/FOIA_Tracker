</td><td style="width:5px"></td>
</tr></table>

	<style type=text/css>
		.footers {
			color: white;
			font-size: 9pt;
			font-family: arial;
			margin-left: 10px;
			text-decoration: none;
		}
		.footers A:link {
			color: white;
			text-decoration: underline;
		}
		.footers A:visited {
			color: white;
			text-decoration: underline;
		}
		.footers A:hover {
			color: yellow;
			text-decoration: underline;
		}
		.footers A:active {
			color: yellow;
			text-decoration: underline;
		}

	</style>

<iframe id=divblocker scrolling=0 style='height:0px; width:0px' frameborder=0 style='background-color:white; border:none; border-width:0px'></iframe>
<div id=divshadow></div>
<div id=divprefsshadow></div>
<div id=divprefs></div>

<div id=b0 style='height:20px;'></div>
<div id=b1 style='width:100%;  background-color:9E7BFF'>
   <div id=b1a style='padding-left:10px; padding-top:10px; padding-bottom:10px; padding-right:10px;' class='footers'>


	<p>FOIA, version <?
		echo $version_no;
	?>
	by Brad Heath / <a href=mailto:brad.heath@gmail.com>brad.heath@gmail.com</a> <br />
	<a target=_blank href="http://www.gnu.org/licenses/gpl-3.0.txt">GNU General Public License, Version 3</a> for public use and distribution.
   
   </div>
</div>
<div id=b1 style='width:100%; height:10px; background-color:7A5DC7'>
</div>


</div>


</body>
</html>